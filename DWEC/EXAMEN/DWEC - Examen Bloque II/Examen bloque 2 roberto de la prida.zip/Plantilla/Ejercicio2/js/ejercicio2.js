document.getElementById("botonRestaurar").addEventListener("click", () => location.reload());
